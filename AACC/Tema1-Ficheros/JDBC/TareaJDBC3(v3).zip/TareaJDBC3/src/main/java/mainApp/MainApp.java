package mainApp;

import jframeApp.SwingApp;

/**
 * Clase para Iniciar la App
 */
public class MainApp {
	
	public static void main(String[] args) {
		SwingApp swing = new SwingApp();
		swing.setVisible(true);
	}
}